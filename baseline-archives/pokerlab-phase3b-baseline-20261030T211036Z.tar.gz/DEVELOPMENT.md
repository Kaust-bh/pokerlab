# Development notes

## Phase 2 design decisions

- The engine remains agent-independent. `agents.base.observe` creates a player-specific view and a small legal action abstraction.
- Agent factories create new instances for each match. The tournament runner resets each instance with a local seeded stream.
- Equity deals unknown cards from one precomputed unseen-card set per estimate. Exact enumeration groups by final board so the hero hand is evaluated only once for each board.
- Exact enumeration is automatic up to 100,000 outcomes and capped at 2,000,000 when explicitly requested. Monte Carlo intervals use Hoeffding's inequality for equity outcomes of 0, 0.5, or 1.
- Button position alternates by hand and initial button alternates between independent matches. Tournament stack totals are checked after each hand.
- Match confidence intervals use a normal approximation over independent match-level profit-per-hand observations; report them as approximate, especially for small samples.

## Run checks and experiments

```sh
pytest
ruff check .
ruff format --check .
PYTHONPATH=src python -m pokerlab.benchmark_cli --matches 20 --hands 100 --equity-simulations 100 --seed 2026
```

Benchmark output is explicitly preliminary. The framework does not infer agent strength from a small sample.

## Recorded Phase 2 benchmark

The recorded workspace benchmark used 250 matches per pairing, a 50-hand cap, 5,000 starting chips, 1/2 blinds, 25 Monte Carlo samples per EquityAgent decision, and seed `20261031`. Aggregate match win rates (with approximate 95% intervals) were:

| Matchup | Hands | Win rate | 95% interval |
|---|---:|---:|---:|
| Random A vs Random B | 1,298 | 0.536 | 0.474–0.598 |
| Heuristic vs Random | 4,268 | 0.664 | 0.605–0.723 |
| Equity vs Random | 1,942 | 0.684 | 0.626–0.742 |
| Equity vs Heuristic | 12,500 | 0.622 | 0.562–0.682 |
| Heuristic A vs Heuristic B | 12,500 | 0.442 | 0.381–0.503 |

The complete CSV is `results/phase2_benchmark.csv`. These are exploratory results, not evidence that one strategy is generally stronger. Random-agent matches frequently ended before the hand cap, and the baseline policies and equity sample budget are intentionally simple.

## Phase 3A: Kuhn Poker vanilla CFR

### Implemented

- `research/kuhn/game.py`: J/Q/K chance deals, legal action histories, terminal detection, and net-chip zero-sum utilities.
- `research/kuhn/information_sets.py`: stable acting-player observations that omit the opponent's card.
- `research/kuhn/strategy.py`: regret matching, own-reach-weighted average-strategy normalization, and JSON snapshots.
- `research/kuhn/cfr.py`: simultaneous full-tree vanilla CFR updates over all six ordered deals.
- `research/kuhn/evaluation.py`: exact expected value, information-set-consistent pure best responses, NashConv, and exploitability.
- `research/kuhn/experiments.py`: reproducible training, CSV and strategy export, CLI, and Plotly convergence output.

### Mathematical conventions

Utilities are Player 0's net chips after both antes: showdown after check-check is ±1; a called bet showdown is ±2; a fold awards the bettor +1. Player 1 receives the negative utility. Counterfactual regret uses chance reach times opponent reach, excluding the acting player's reach. To compute average strategy, each information set is coalesced once per iteration and weighted by the acting player's own reach. This is the behavioral-strategy average, not the final current strategy.

NashConv is the sum of Player 0's and Player 1's best-response gains against the profile. This project reports exploitability as NashConv/2; some sources use “exploitability” for NashConv itself, so both values are exported.

The six chance deals and public action branches are traversed exactly. Best responses enumerate the Kuhn player's pure information-set policies, so choices cannot condition on hidden opponent cards. The implementation is vanilla full-tree CFR, not MCCFR or Deep CFR.

### Validation and recorded experiment

Tests validate every terminal history and payoff, information-set identity/privacy, first-iteration counterfactual regret (including the 1/8 Jack-root bet regret), average reach weighting, regret matching, strategy snapshots, exact known equilibrium value and best responses, and a 5,000-iteration convergence run. The full suite passes **62 tests**; Ruff checks and formatting pass.

The reproducible 10,000-iteration experiment used seed `7`, evaluation every 100 iterations, and logging every 1,000 iterations. At iteration 10,000, Player 0's average-profile expected value was `−0.055546` chips per hand (reference `−1/18 ≈ −0.055556`), NashConv was `0.004636`, and exploitability was `0.002318`. Exploitability declined from `0.007269` at iteration 1,000. The learned first-player opening frequencies were J `0.208`, Q `0.000`, K `0.613`; this is one approximate member of Kuhn's equilibrium family rather than a unique target strategy.

Generated outputs are `results/kuhn/convergence.csv`, `results/kuhn/average_strategy.json`, and `results/kuhn/convergence.html`.

### Limitations and next steps

Kuhn's solver and exact best-response enumeration are specialized to its small tree. It does not implement CFR+, sampled CFR, subgame solving, or NLHE CFR. Leduc is implemented separately below and does not alter this Kuhn code.

References: [Kuhn, “A Simplified Two-Person Poker” (1950)](https://sites.math.rutgers.edu/~zeilberg/akherim/PokerPapers/Kuhn1951.pdf); [Zinkevich et al., “Regret Minimization in Games with Incomplete Information” (NIPS 2007)](https://proceedings.neurips.cc/paper/2007/file/08d98638c6fcd194a4b1e6992063e944-Paper.pdf).

## Phase 3B: Leduc Poker vanilla CFR

### Selected rules

The implementation follows the two-bet-maximum Leduc Hold'em described by Southey et al. The deck has two physical suits of J, Q, and K; both players ante one chip and receive one private card. Player 0 acts first in round one. A check-check or a called bet advances to the public-card chance node; a fold ends the hand. Player 1 acts first in round two. Bet sizes are two chips in round one and four in round two. A round permits one opening bet and one raise maximum; after the raise, only fold and call are legal. This defines “two-bet maximum” precisely and prevents mixing it with variants that permit additional raises. There are no blinds, rake, stacks, or side pots.

An opening bet adds one round unit to the bettor's contribution. A raise first matches the outstanding wager and adds one more unit, so it contributes twice the round's bet size; the caller then matches the additional unit. A fold winner's net payoff is the folded player's contribution. At showdown the winner's net is the opponent's total contribution, and a tie returns zero to both. Utilities are therefore net chips after ante and action contributions and sum to zero in every terminal state.

### Information sets and CFR

`research/leduc/game.py` contains the full hidden state and explicit public-card chance node. `information_sets.py` groups states using the acting player, their physical private card, the public card if revealed, round index, and the public action histories. The other private card and undealt cards never enter the key. Histories are full game-tree states; information sets are player observations that may contain many histories.

The solver visits all 30 ordered private deals and all four available public cards after a non-folded first round. At `I` for player `i`, regret uses chance reach and opponent reach, excluding `i`'s own reach. It adds `π_-i(h) * (v_i(h,a) - v_i(h))` for each compatible history. Average behavioral strategy accumulates `π_i(I) * σ_i(I,a)`, excluding opponent reach. Compatible physical hidden-card states share own reach for this observation, so the solver coalesces them once per iteration. Strategy deltas are committed only after all chance outcomes have been traversed, matching the simultaneous Kuhn convention.

Exact best responses use backward information-set optimization. For each candidate response information set, the evaluator sums action values across its full histories with chance and opponent reach weights, then chooses one action for the entire information set. It does not enumerate opponent private cards as if they were known. NashConv sums both best-response gains; reported exploitability is NashConv divided by two.

Run training and evaluation:

```sh
PYTHONPATH=src python -m pokerlab.research.leduc.experiments \
  --iterations 1000 --seed 7 --evaluation-interval 1000 \
  --logging-interval 1000 --output-dir results/leduc --compare-kuhn
PYTHONPATH=src python -m pokerlab.research.kuhn.experiments \
  --iterations 1000 --seed 7 --evaluation-interval 1000 \
  --logging-interval 1000 --output-dir results/kuhn
```

CSV records include iteration, expected value, NashConv, exploitability, information-set count, runtime, tree node count, training iterations per second, and best-response runtime. Average strategy snapshots are JSON; plots show exploitability, NashConv, and expected value. `--compare-kuhn` runs Kuhn at the same iteration count and seed and saves a side-by-side CSV. The selected variant traverses 9,450 nodes and has 936 information sets per complete iteration. Exact best-response passes take longer than a training iteration, so long runs should use a wider evaluation interval.

### Recorded 5,000-iteration comparison

Both solvers were run with seed `7`, 5,000 iterations, and evaluation every 500 iterations. Leduc's average-profile Player 0 value was `−0.008098`, NashConv `0.029563`, and exploitability `0.014781` at the end. Exploitability declined from `0.057890` at 500 iterations; value was between `−0.007798` and `−0.008098` from iterations 3,000–5,000. Kuhn reached value `−0.055506`, NashConv `0.006605`, and exploitability `0.003302`. Leduc traversed 9,450 nodes per iteration and had 936 information sets; Kuhn traversed 54 nodes per iteration and had 12 information sets. Their chips-per-hand scales differ, so raw exploitability is contextual rather than a direct strength comparison. Leduc trained at 17.42 iterations/s and took 287.00 seconds including exact best-response evaluations. The paired comparison Kuhn run trained at 2,769 iterations/s and took 1.81 seconds. CSV, strategy, and plot outputs are under results/leduc/; the comparison CSV is in the same directory.

Reference: [Southey et al., “Bayes' Bluff: Opponent Modeling in Poker” (UAI 2005)](https://poker.cs.ualberta.ca/publications/UAI05.pdf), which defines the six-card deck, ante, two-bet maximum, and round bet sizes.
