import math

from pokerlab.research.leduc.cfr import CFRConfig, CFRSolver
from pokerlab.research.leduc.evaluation import evaluate_nash


def test_average_profile_remains_valid_after_short_training():
    solver = CFRSolver(CFRConfig(iterations=4, seed=13))
    solver.train(iterations=4, evaluation_interval=4)
    profile = solver.average_strategy_profile()
    assert len(profile) == 936
    assert all(
        math.isclose(sum(distribution.values()), 1.0)
        for distribution in profile.values()
    )
    result = evaluate_nash(profile)
    assert math.isfinite(result.expected_value_player0)
    assert result.exploitability >= 0
