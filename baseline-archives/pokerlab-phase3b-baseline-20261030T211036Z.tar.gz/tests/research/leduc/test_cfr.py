import math

from pokerlab.research.leduc.betting import Action
from pokerlab.research.leduc.cards import DECK
from pokerlab.research.leduc.cfr import CFRConfig, CFRSolver
from pokerlab.research.leduc.game import LeducGame
from pokerlab.research.leduc.information_sets import InformationSet
from pokerlab.research.leduc.strategy import normalize_average_strategy, regret_matching


def test_regret_matching_and_average_strategy_are_valid():
    legal = (Action.FOLD, Action.CALL, Action.RAISE)
    assert regret_matching({}, legal) == {a: 1 / 3 for a in legal}
    assert regret_matching(
        {Action.FOLD: -2, Action.CALL: 3, Action.RAISE: 1}, legal
    ) == {
        Action.FOLD: 0,
        Action.CALL: 0.75,
        Action.RAISE: 0.25,
    }
    average = normalize_average_strategy(
        {Action.FOLD: 2, Action.CALL: 0, Action.RAISE: 2}, legal
    )
    assert average == {Action.FOLD: 0.5, Action.CALL: 0, Action.RAISE: 0.5}


def test_full_tree_iteration_builds_valid_strategies_and_counters():
    solver = CFRSolver(CFRConfig(iterations=1, seed=17))
    solver.run_iteration()
    assert solver.iterations == 1
    assert solver.game_tree_nodes == 9_450
    assert len(solver.regret_sum) == 936
    for info, strategy in solver.average_strategy_profile().items():
        legal = solver._legal[info]
        assert set(strategy) == set(legal)
        assert math.isclose(sum(strategy.values()), 1.0)
        assert all(math.isfinite(prob) and prob >= 0 for prob in strategy.values())


def test_cfr_run_is_reproducible_for_fixed_seed():
    first = CFRSolver(CFRConfig(iterations=1, seed=8))
    second = CFRSolver(CFRConfig(iterations=1, seed=8))
    first.run_iteration()
    second.run_iteration()
    assert first.regret_sum == second.regret_sum
    assert first.strategy_sum == second.strategy_sum


def test_info_lookup_derives_only_legal_actions():
    solver = CFRSolver()
    info = InformationSet.from_state(LeducGame.initial_state(DECK[:2]))
    assert set(solver.current_strategy(info)) == {Action.CHECK, Action.BET}


def test_counterfactual_regret_and_average_reach_weights():
    solver = CFRSolver()
    state = LeducGame.initial_state(DECK[:2])
    info = InformationSet.from_state(state)
    solver._ensure(info, state.legal_actions)
    solver.regret_sum[info] = {Action.CHECK: 1.0, Action.BET: 3.0}
    strategy = solver.current_strategy(info)
    regret_delta = {}
    average_delta = {}
    solver._traverse(
        state,
        reach=(0.25, 0.75),
        chance_reach=0.2,
        regrets=regret_delta,
        averages=average_delta,
        averaged=set(),
        node_counter=[0],
    )

    assert math.isclose(strategy[Action.CHECK], 0.25)
    assert math.isclose(strategy[Action.BET], 0.75)
    assert math.isclose(average_delta[info][Action.CHECK], 0.0625)
    assert math.isclose(average_delta[info][Action.BET], 0.1875)
    assert math.isclose(
        sum(strategy[action] * regret_delta[info][action] for action in strategy),
        0.0,
        abs_tol=1e-12,
    )
    assert all(math.isfinite(value) for value in regret_delta[info].values())
